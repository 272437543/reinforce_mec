import numpy as np
import matplotlib.pyplot as plt
import func
import math
import copy
import scipy.io as sio
import random


class SA(object):

    def __init__(self, h, a, f, tab='min', T_max=100, T_min=1, iterMax=2, rate=0.95):
        # self.M = 3        # number of mec
        self.N = 110        # number of user
        self.h = h
        self.f = f
        self.T_max = T_max  # 初始退火温度 - 温度上限
        self.T_min = T_min  # 截止退火温度 - 温度下限
        self.iterMax = iterMax  # 定温内部迭代次数
        self.rate = rate  # 退火降温速度
        self.X_a_seed = a
        self.tab = tab.strip()  # 求解最大值还是最小值的标签: 'min' - 最小值；'max' - 最大值

    def solve(self):
        fitness = [150]
        temp = 'deal_' + self.tab  # 采用反射方法提取对应的函数
        if hasattr(self, temp):
            self.deal = getattr(self, temp)
        else:
            exit('>>>tab标签传参有误："min"|"max"<<<')
        self.X1 = copy.deepcopy(self.X_a_seed)
        self.T = self.T_max
        while self.T >= self.T_min:
            for i in range(self.iterMax):
                f1 = func.func_re(self.X1, self.h, self.f)
                delta_x = np.random.randint(0, self.N)
                self.X2_1 = copy.deepcopy(self.X1)
                self.X2_2 = copy.deepcopy(self.X1)
                self.X2_1[delta_x] = np.argmax(self.h[delta_x]) + 1
                self.X2_2[delta_x] = 0
                f2_1 = func.func_re(self.X2_1, self.h, self.f)
                f2_2 = func.func_re(self.X2_2, self.h, self.f)
                if f2_1 > f2_2:
                    f2 = f2_2
                    self.X2 = self.X2_2
                else:
                    f2 = f2_1
                    self.X2 = self.X2_1
                delta_f = f2 - f1
                # print(delta_f)
                self.X1 = self.deal(self.X1, self.X2, delta_f, self.T)
                fitness.append(func.func_re(self.X1, self.h, self.f))      #  func.func_re(x, self.h, self.f)
            self.T *= self.rate
            # print(self.T)
        self.x_solu = self.X1  # 提取最终退火解
        self.save(fitness, 'asa_dalunwen.txt')
        return self.x_solu, fitness[-1]

    def p_min(self, delta, T):  # 计算最小值时，容忍解的状态迁移概率
        probability = np.exp(-delta / T)
        return probability

    def p_max(self, delta, T):
        probability = np.exp(delta / T)  # 计算最大值时，容忍解的状态迁移概率
        return probability

    def deal_min(self, x1, x2, delta, T):
        if delta < 0:  # 更优解
            return x2
        else:  # 容忍解
            P = self.p_min(delta, T)
            if P > random.random():
                return x1
            else:
                return x2

    def deal_max(self, x1, x2, delta, T):
        if delta > 0:  # 更优解
            return x2
        else:  # 容忍解
            P = self.p_max(delta, T)
            if P > random.random():
                return x2
            else:
                return x1


    def save(self, rate_his, file_path):
        with open(file_path, 'w') as f:
            for rate in rate_his:
                f.write("%s \n" % rate)


if __name__ == '__main__':
    h = sio.loadmat('h_100_10_10000_100x100.mat')['h']
    f = np.zeros(100)
    f = f + 0.01
    h = h[999]
    h = h.reshape(-1, 10)
    a = np.zeros(100)
    sa = SA(h, a, f)   #  TS(h, a, f_re, ue, 20, 2, 20)
    a, q = sa.solve()
    print(str(a).count('0'))
    print(a, q)

    plot.plot_re('asa_dalunwen.txt', 'iteration', 'fitness')