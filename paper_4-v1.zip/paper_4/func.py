import numpy as np
import math

Delta = 1e-12
B = 1e6
Di = 2e7
M = 10
Fi = 1e9
Fmec = 23e9
ue = 110

def tfunc(h, n):
    T_tran = Di / (B * math.log((1 + h**2 / Delta), 2))
    QoS = T_tran + Fi * n / Fmec
    return QoS


def fitness(pred, m):
    counter = 0
    for i in range(pred.shape[0]):
        if pred[i] == m[i]:
            counter += 1
    return counter


def allow4(a, f):
    F = np.zeros(50)
    S = np.zeros(4)
    for j in range(4):
        idx = [i for i,x in enumerate(a) if x == j+1]
        f1 = f[idx]
        S[j] =sum(f1)
        # print('S', S[j])
        # print('idx1', idx)
    for k in range(50):
        # print(f[k])
        if a[k] == 0:
            F[k] = 1e9
        elif a[k] == 1:
            F[k] = f[k] * Fmec /(S[0]+1e-9)
        elif a[k] == 2:
            F[k] = f[k] * Fmec /(S[1]+1e-9)
        elif a[k] == 3:
            F[k] = f[k] * Fmec /(S[2]+1e-9)
        elif a[k] == 4:
            F[k] = f[k] * Fmec / (S[3] + 1e-9)
    # print('allow', F, sum(F))
    return F


def allow(a, f):
    F = np.zeros(ue)
    S = np.zeros(M)
    count = np.zeros(M)
    for j in range(M):
        idx = [i for i,x in enumerate(a) if x == j+1]
        f1 = f[idx]
        S[j] =sum(f1)
        count[j] = len(idx)
        # print('S', S[j])
        # print('idx1', idx)
    for k in range(ue):
        # print(f[k])
        if a[k] == 0:
            F[k] = 1e9
        elif a[k] == 1:
            F[k] = 0.1* f[k] * Fmec /(S[0]+1e-9) + 0.9*Fmec/(count[0]+1e-9)
        elif a[k] == 2:
            F[k] = 0.1*f[k] * Fmec /(S[1]+1e-9) + 0.9*Fmec/(count[1]+1e-9)
        elif a[k] == 3:
            F[k] = 0.1*f[k] * Fmec /(S[2]+1e-9) + 0.9*Fmec/(count[2]+1e-9)
        elif a[k] == 4:
            F[k] = 0.1*f[k] * Fmec /(S[3]+1e-9) + 0.9*Fmec/(count[3]+1e-9)
        elif a[k] == 5:
            F[k] = 0.1*f[k] * Fmec /(S[4]+1e-9) + 0.9*Fmec/(count[4]+1e-9)
        elif a[k] == 6:
            F[k] = 0.1*f[k] * Fmec /(S[5]+1e-9) + 0.9*Fmec/(count[5]+1e-9)
        elif a[k] == 7:
            F[k] = 0.1*f[k] * Fmec /(S[6]+1e-9) + 0.9*Fmec/(count[6]+1e-9)
        elif a[k] == 8:
            F[k] = 0.1*f[k] * Fmec /(S[7]+1e-9) + 0.9*Fmec/(count[7]+1e-9)
        elif a[k] == 9:
            F[k] = 0.1*f[k] * Fmec /(S[8]+1e-9) + 0.9*Fmec/(count[8]+1e-9)
        elif a[k] == 10:
            F[k] = 0.1*f[k] * Fmec /(S[9]+1e-9) + 0.9*Fmec/(count[9]+1e-9)

    # print('allow', F, sum(F))
    return F


def func(a, h):  # 状态产生函数 - 即待求解函数
    # a = self.allow(X)
    n = np.zeros(M)
    for i in range(M):
        n[i] = str(a).count(str(i+1))
    T = 0
    for j in range(50):
        if a[j] == 0:
            tran = 1.5
        else:
            # print(a)
            r = B * math.log((1 + h[j, int(a[j]) - 1] / Delta), 2)
            tran = Di / r + Fi * n[int(a[j]) - 1] / Fmec

        T = T + tran
    # print('time', T)
    return T


def func_re(a, h, f):  # 状态产生函数 - 即待求解函数
    f_a = allow(a,f)
    T = 0
    for j in range(ue):
        if a[j] == 0:
            tran = 1.5
        else:
            # print(a)
            r = B * math.log((1 + (h[j, int(a[j]) - 1])**2 / Delta), 2)
            tran = Di / r + Fi / (f_a[j]+1)
            # print(Di / r, Fi / (f_a[j]+1))
        T = T + tran
    # print('time', T)
    return T


def func_single(a, h, f, ind):  # 状态产生函数 - 即待求解函数
    f_a = allow(a,f)
    T = []
    for j in range(100):
        if a[j] == 0:
            tran = 1.5
        else:
            # print(a)
            r = B * math.log((1 + (h[j, int(a[j]) - 1])**2 / Delta), 2)
            tran = Di / r + Fi / (f_a[j]+1)
            # print(Di / r, Fi / (f_a[j]+1))
        T.append(tran)
    # print('time', T)
    return T[ind]

def func_re4(a, h, f, label, hd):  # 状态产生函数 - 即待求解函数
    h_new = np.zeros((50, 4))
    for i in range(50):
        # print('h--------------', h[i])
        h_new[i] = np.insert(h[i], label[i], hd[i])
        # print(h_new[i])
        if label[i] < a[i]:
            a[i] = a[i] + 1
    f_a = allow4(a, f)
    T = 0
    for j in range(50):
        if a[j] == 0:
            tran = 1.5
        else:
            # print(a)
            r = B * math.log((1 + (h_new[j, int(a[j]) - 1])**2 / Delta), 2)
            tran = Di / r + Fi / (f_a[j]+1)
            # print(Di / r, Fi / (f_a[j]+1))
        T = T + tran
    # print('time', T)
    return T

def func_re1114(a, h):  # 状态产生函数 - 即待求解函数
    f_a = allow1114(a)
    T = 0
    for j in range(50):
        if a[j] == 0:
            tran = 1.5
        else:
            # print(a)
            r = B * math.log((1 + (h[j, int(a[j]) - 1])**2 / Delta), 2)
            tran = Di / r + Fi / (f_a[j]+1)
            # print(Di / r, Fi / (f_a[j]+1))
        T = T + tran
    # print('time', T)
    return T


def allow1114(a):
    F = np.zeros(50)
    a_s = str(a)
    for k in range(50):
        # print(f[k])
        if a[k] == 0:
            F[k] = 1e9
        else:
            F[k] = Fmec /a_s.count(str(int(a[k])))
    # print('allow', F, sum(F))
    return F

def func_re_wuxian(a, h, f):  # 状态产生函数 - 即待求解函数
    f_a = f
    T = 0
    for j in range(50):
        if a[j] == 0:
            tran = 1.5
        else:
            # print(a)
            r = B * math.log((1 + (h[j, int(a[j]) - 1])**2 / Delta), 2)
            tran = Di / r + Fi / (f_a[j]+1)
            # print(Di / r, Fi / (f_a[j]+1))
        T = T + tran
    # print('time', T)
    return T
