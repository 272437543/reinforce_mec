from __future__ import division
from __future__ import print_function
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Dense, Dropout, Activation, Flatten, LeakyReLU, Input
from tensorflow.keras import optimizers
import numpy as np
import func
from ASA import SA
from tensorflow.keras import backend as K
from scipy.io import loadmat


class Constraint(object):

    def __call__(self, w):
        return w

    def get_config(self):
        return {}

class MaskWeights(Constraint):

    def __init__(self, mask, initial):
        self.mask = mask
        self.initial = initial
        self.mask = K.cast(self.mask, K.floatx())
        self.initial = K.cast(self.initial, K.floatx())

    def __call__(self, w):
        w = self.mask * w + self.initial
        return w

    def get_config(self):
        return {'mask': self.mask}


def find_first_pos(array, value):
    idx = (np.abs(array - value)).argmin()
    return idx


def find_last_pos(array, value):
    idx = (np.abs(array - value))[::-1].argmin()
    return array.shape[0] - idx


def createWeightsMask(epsilon,noRows, noCols):
    # generate an Erdos Renyi sparse weights mask
    mask_weights = np.random.rand(noRows, noCols)
    prob = 1 - (epsilon * (noRows + noCols)) / (noRows * noCols)  # normal tp have 8x connections
    mask_weights[mask_weights < prob] = 0
    mask_weights[mask_weights >= prob] = 1
    noParameters = np.sum(mask_weights)
    print ("Create Sparse Matrix: No parameters, NoRows, NoCols ",noParameters,noRows,noCols)
    return [noParameters,mask_weights]


class SET_DRL:
    def __init__(self):
        # set model parameters
        self.batch_size = 500 # batch size
        self.maxepoches = 500 # number of epochs
        self.learning_rate = 0.01 # SGD learning rate
        self.N = 10 # number of classes
        self.ue = 110
        self.momentum=0.9 # SGD momentum
        self.memory_size = 11000
        self.memory_size_ = 100
        self.memory_counter = 0

        self.w1 = np.load('w1.npy',allow_pickle=True)
        # print(self.w1)
        self.w2 = np.load('w2.npy',allow_pickle=True)
        self.w3 = np.load('w3.npy',allow_pickle=True)
        self.w4 = np.load('w4.npy',allow_pickle=True)

        self.wm1 = loadmat('weights_SET0.5_mat.mat')['mask1']
        self.wm2 = loadmat('weights_SET0.5_mat.mat')['mask2']
        self.wm3 = loadmat('weights_SET0.5_mat.mat')['mask3']

        self.inw1 = loadmat('weights_SET0.5_mat.mat')['w1']
        self.inw2 = loadmat('weights_SET0.5_mat.mat')['w2']
        self.inw3 = loadmat('weights_SET0.5_mat.mat')['w3']

        self.create_model()

        datas = loadmat('h_110_10_1000_100x100.mat')['h']

        self.model.summary()

        # training process in a for loop
        self.accuracies_per_epoch=[]
        self.val_accuracies_per_epoch=[]
        self.losses_per_epoch=[]
        self.val_losses_per_epoch=[]
        self.re_his = []

        self.memory = np.zeros((self.memory_size, 2*self.N+2))

        # train the SET-MLP model
        for epoch in range(0,self.maxepoches):
            if epoch % (self.maxepoches // 100) == 0:
                print("%0.3f" % (epoch / self.maxepoches))
            # print(epoch)
            h_train = datas[epoch].reshape((self.ue, self.N))
            # print('train',h_train)
            pred_old = self.model.predict(h_train)
            pred_a = pred_old[:, 0:self.N+1]
            # print(pred.shape)
            pred_f = pred_old[:, -1]
            pred_f = pred_f.reshape(-1)
            m_train = pred_f.reshape(-1,1)
            pred_ = np.zeros(self.ue)
            for i in range(len(pred_a)):
                pred_[i] = np.argmax(pred_a[i])
            sa = SA(h_train, pred_, pred_f)
            m, q = sa.solve()
            print('m', q)
            y_train = np.zeros((self.ue, self.N+1))
            for i in range(self.ue):
                y_train[i][int(m[i])] = 1
            # print('f',pred_f)
            re = func.func_re(pred_, h_train, pred_f)
            self.re_his.append(1 / re)
            print('re',re)
            self.remember(h_train,y_train,m_train)

            # get sample#
            if self.memory_counter*self.ue > self.memory_size:
                sample_index = np.random.choice(self.memory_size, size=self.batch_size)
            else:
                sample_index = np.random.choice(self.memory_counter*self.ue, size=self.batch_size)
            batch_memory = self.memory[sample_index, :]
            H_train = batch_memory[:, 0: self.N]
            m_train = batch_memory[:, self.N:]

            self.train(H_train, m_train)

    def remember(self, h, a, m):
        # replace the old memory with new memory
        idx = self.memory_counter % self.memory_size_
        self.memory[self.ue*idx:self.ue*(idx+1), :] = np.hstack((h, a, m))
        self.memory_counter += 1


    def create_model(self):

        # create a SET-MLP model for CIFAR10 with 3 hidden layers
        self.model = Sequential()
        self.model.add(Dense(32, input_dim=self.N, name="sparse_1",kernel_constraint=MaskWeights(self.wm1,self.inw1),weights=self.w1))
        self.model.add(LeakyReLU(name="srelu1"))
        self.model.add(Dense(64, name="sparse_2",kernel_constraint=MaskWeights(self.wm2,self.inw2),weights=self.w2))
        self.model.add(LeakyReLU(name="srelu2"))
        self.model.add(Dense(32, name="sparse_3",kernel_constraint=MaskWeights(self.wm3,self.inw3),weights=self.w3))
        self.model.add(LeakyReLU(name="srelu3"))
        self.model.add(Dense(self.N+2, name="dense_4",weights=self.w4)) #please note that there is no need for a sparse output layer as the number of classes is much smaller than the number of input hidden neurons
        self.model.add(Activation('sigmoid'))

    def weightsEvolution(self):
        # this represents the core of the SET procedure. It removes the weights closest to zero in each layer and add new random weights
        self.w1 = self.model.get_layer("sparse_1").get_weights()
        self.w2 = self.model.get_layer("sparse_2").get_weights()
        self.w3 = self.model.get_layer("sparse_3").get_weights()
        self.w4 = self.model.get_layer("dense_4").get_weights()

    def train(self, x_train, y_train):

        self.model.compile(loss='categorical_crossentropy',
                           optimizer=optimizers.Adam(learning_rate=0.001),
                           metrics='accuracy')

        historytemp = self.model.fit(x_train, y_train, epochs=2,
                                     validation_data=(x_train, y_train),
                                     verbose=0)
        # print(historytemp.history)
        self.accuracies_per_epoch.append(historytemp.history['accuracy'][0])
        self.val_accuracies_per_epoch.append(historytemp.history['val_accuracy'][0])
        self.losses_per_epoch.append(historytemp.history['loss'][0])
        self.val_losses_per_epoch.append(historytemp.history['val_loss'][0])

        #ugly hack to avoid tensorflow memory increase for multiple fit_generator calls. Theano shall work more nicely this but it is outdated in general
        self.weightsEvolution()
        K.clear_session()
        self.create_model()



if __name__ == '__main__':

    # create and run a SET-MLP model on CIFAR10
    model=SET_DRL()
    np.savetxt("pack_loss110.txt", np.asarray(model.losses_per_epoch))
    np.savetxt('pack_reward110.txt', np.asarray(model.re_his))




